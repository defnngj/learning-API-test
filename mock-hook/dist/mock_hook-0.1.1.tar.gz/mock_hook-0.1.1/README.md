# mock-hook


## install

* 打包

```bash
> python3.9 -m poetry build
```

* 安装

```bash
> python3.9 -m pip install ./dist/mock_hook-0.1.1-py3-none-any.whl
```

* 卸载

```bash
> python3.9 -m pip uninstall mock_hook
```

## Used

* `mock` cli tools.

```
> mock --help
Usage: mock [OPTIONS]

  Simple program that greets NAME for a total of COUNT times.

Options:
  --count INTEGER  Number of greetings.
  --name TEXT      The person to greet.
  --help           Show this message and exit.
```